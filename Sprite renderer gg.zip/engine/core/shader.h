#pragma once

#include <string>

#include "math.h"

namespace Apex
{
    class Shader
    {
    public:
        Shader() = default;
        Shader(const char* vertexPath, const char* fragmentPath);
        ~Shader();

        Shader(const Shader&) = delete; // disable copy const
        Shader& operator=(const Shader&) = delete;

        Shader(Shader&& other) noexcept; // we want this and most of our engine classes to work with std::move, ownership decision
        Shader& operator=(Shader&& other) noexcept;

        void use();

        unsigned int getID() const {return m_ID;}

        void setBool(const std::string &name, bool value) const;
        void setInt(const std::string &name, int value) const;
        void setFloat(const std::string &name, float value) const;
        void setMat4(const std::string &name, const Math::Mat4& matrix) const;

    private:
        void checkCompileErrors(unsigned int shader, std::string type);

        unsigned int m_ID{0};
    };
}